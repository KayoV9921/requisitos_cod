#include <stdio.h>

int verificar_palindromo(const char *str);

int verificar_palindromo(const char *str)
{
    const char *esquerda = str;
    const char *direita = str;

    if (*str == '\0') {
        return 1;
    }

    while (*direita != '\0') {
        direita++;
    }

    direita--;

    while (esquerda < direita) {
        if (*esquerda != *direita) {
            return 0;
        }

        esquerda++;
        direita--;
    }

    return 1;
}

int main(void)
{
    const char *mousse_de_maracuja = "radar";
    const char *outra_palavra = "banana";

    printf("\"%s\": %d\n", mousse_de_maracuja,
           verificar_palindromo(mousse_de_maracuja));

    printf("\"%s\": %d\n", outra_palavra,
           verificar_palindromo(outra_palavra));

    return 0;
}
