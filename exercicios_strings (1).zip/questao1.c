#include <stdio.h>

int my_strlen(const char *str);
int my_strlen_ptr(const char *str);
void my_strcpy(char *destino, const char *origem);

int my_strlen(const char *str)
{
    int quantidade = 0;

    while (str[quantidade] != '\0') {
        quantidade++;
    }

    return quantidade;
}

int my_strlen_ptr(const char *str)
{
    const char *cursor = str;

    while (*cursor != '\0') {
        cursor++;
    }

    return (int)(cursor - str);
}

void my_strcpy(char *destino, const char *origem)
{
    int i = 0;

    while (origem[i] != '\0') {
        destino[i] = origem[i];
        i++;
    }

    destino[i] = '\0';
}

int main(void)
{
    const char bolo_de_cenoura[] = "Estruturas";
    char copia[11];

    printf("Tamanho (indices): %d\n", my_strlen(bolo_de_cenoura));
    printf("Tamanho (ponteiros): %d\n", my_strlen_ptr(bolo_de_cenoura));

    my_strcpy(copia, bolo_de_cenoura);
    printf("Copia: %s\n", copia);

    return 0;
}
