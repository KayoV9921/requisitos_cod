#include <stdio.h>

int my_strstr(const char *texto, const char *padrao);

int my_strstr(const char *texto, const char *padrao)
{
    int i = 0;

    if (padrao[0] == '\0') {
        return 0;
    }

    while (texto[i] != '\0') {
        int j = 0;

        while (texto[i + j] != '\0'
               && padrao[j] != '\0'
               && texto[i + j] == padrao[j]) {
            j++;
        }

        if (padrao[j] == '\0') {
            return i;
        }

        i++;
    }

    return -1;
}

int main(void)
{
    const char *suco_de_limao = "Estrutura de Dados em C";
    const char *alvo = "Dados";

    printf("Indice encontrado: %d\n",
           my_strstr(suco_de_limao, alvo));

    printf("Indice de \"Java\": %d\n",
           my_strstr(suco_de_limao, "Java"));

    return 0;
}
