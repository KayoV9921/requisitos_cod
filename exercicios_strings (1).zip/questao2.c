#include <stdio.h>

int my_strcmp(const char *str1, const char *str2);

int my_strcmp(const char *str1, const char *str2)
{
    int i = 0;

    while (str1[i] != '\0' && str2[i] != '\0') {
        if (str1[i] != str2[i]) {
            return (unsigned char)str1[i] - (unsigned char)str2[i];
        }

        i++;
    }

    return (unsigned char)str1[i] - (unsigned char)str2[i];
}

int main(void)
{
    const char *vinho_tinto = "vinho";
    const char *vinho_branco = "branco";

    printf("Comparacao 1: %d\n", my_strcmp(vinho_tinto, vinho_branco));
    printf("Comparacao 2: %d\n", my_strcmp("arroz", "arroz"));
    printf("Comparacao 3: %d\n", my_strcmp("uva", "banana"));

    return 0;
}
